import 'dart:io';
import 'package:flutter/material.dart';
import 'package:peom_app_project/poem.dart';
import 'package:peom_app_project/colors.dart' as colors;
import 'package:peom_app_project/poets.dart';
import 'package:flutter/services.dart';

class PoemListScreen extends StatelessWidget {
  const PoemListScreen({super.key, required this.id});

  final int id;

  // Import for rootBundle

  Future<List<String>> _loadPoems(String filePath) async {
    try {
      // Read the file content using rootBundle
      final content = await rootBundle.loadString(filePath);

      // Split content by double newlines to separate poems
      return content
          .split(RegExp(r'\n\s*\n')) // Use a regex to split by empty lines
          .map((e) => e.trim()) // Trim whitespace
          .where((e) => e.isNotEmpty) // Remove empty strings
          .map((e) => e.split('\n').first.trim()) // Extract the first line
          .toList();
    } catch (e) {
      // Handle and print the error
      debugPrint('Error reading file: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    // Path to the text file

    final filePath = poets[id - 1].peomPath;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          poets[id - 1].name,
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: colors.appbar_two,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors.gradient_two,
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        child: FutureBuilder<List<String>>(
          future: _loadPoems(filePath),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return const Center(child: Text('Error loading poems'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No poems available'));
            }

            final items = snapshot.data!;

            return ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(
                    textAlign: TextAlign.start,
                    items[index],
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(color: Colors.white, fontSize: 18),
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PoemScreen(id: id, index: index),
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}
