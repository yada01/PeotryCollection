import 'package:flutter/material.dart';

final List<Color> gradient_one = [
  Color.fromARGB(255, 68, 204, 255),
  Color.fromARGB(255, 46, 189, 241)
];

final List<Color> gradient_two = [
  Color.fromARGB(255, 25, 114, 120),
  Color.fromARGB(255, 21, 114, 121)
];

final List<Color> gradient_three = [
  Color.fromARGB(255, 84, 56, 220),
  Color.fromARGB(255, 90, 57, 255)
];

final Color appbar_one = Color.fromARGB(255, 0, 123, 168);
final Color appbar_two = Color.fromARGB(255, 0, 84, 90);
final Color appbar_three = Color.fromARGB(255, 40, 11, 189);

final Color login_color = Color.fromARGB(255, 255, 253, 130);
