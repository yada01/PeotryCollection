import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:peom_app_project/colors.dart' as colors;
import 'package:peom_app_project/poets.dart';

class PoemScreen extends StatefulWidget {
  @override
  _PoemScreenState createState() => _PoemScreenState();

  PoemScreen({required this.id, required this.index});

  final int id;
  final int index;
}

class _PoemScreenState extends State<PoemScreen> {
  bool _isFavorited = false;

  List<String> poemLines = [];

  @override
  void initState() {
    super.initState();
    _loadPoem();
  }

  Future<void> _loadPoem() async {
    try {
      // Use rootBundle to load the asset file
      final fileContent =
          await rootBundle.loadString(poets[widget.id - 1].peomPath);
      setState(() {
        // Split by empty lines and trim whitespace
        poemLines = fileContent
            .split(RegExp(r'\n\s*\n'))
            .map((line) => line.trim())
            .toList();
      });
    } catch (e) {
      // Handle file read error
      print('Error reading file: $e');
      setState(() {
        poemLines = ['Error loading poem'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final peom = (poemLines.isNotEmpty && widget.index < poemLines.length)
        ? poemLines[widget.index]
        : 'No content available';

    return Scaffold(
      appBar: AppBar(
        title: Text(
          poets[widget.id - 1].name,
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: colors.appbar_three,
        actions: [
          IconButton(
            icon: Icon(
              Icons.favorite,
              color: _isFavorited ? Colors.red : Colors.white,
            ),
            onPressed: () {
              setState(() {
                _isFavorited = !_isFavorited;
              });
            },
          ),
          SizedBox(
            width: 12,
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors.gradient_three,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          children: [
            Opacity(
              opacity: 0.2,
              child: Image.asset(
                poets[widget.id - 1].image,
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
              ),
            ),
            SingleChildScrollView(
              child: Container(
                alignment: Alignment.topRight,
                padding: EdgeInsets.all(8),
                child: Text(
                  peom,
                  style: TextStyle(fontSize: 20, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
