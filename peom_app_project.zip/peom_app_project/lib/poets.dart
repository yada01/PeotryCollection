import 'dart:io';

class Poets {
  int id;
  String name;
  String image;
  String peomPath;

  Poets({
    required this.id,
    required this.name,
    required this.image,
    required this.peomPath,
  });
}

List<Poets> poets = [
  Poets(
    id: 1,
    name: "Kurdi",
    image: "lib/images/kurdi.jpg",
    peomPath: "lib/poems/kurdi.txt",
  ),
  Poets(
    id: 2,
    name: "Mahui",
    image: "lib/images/mahui.jpg",
    peomPath: "lib/poems/mahui.txt",
  ),
  Poets(
    id: 3,
    name: "Mawlaui",
    image: "lib/images/mawlaui.jpg",
    peomPath: "lib/poems/mawlaui.txt",
  ),
  Poets(
    id: 4,
    name: "Nali",
    image: "lib/images/nali.jpg",
    peomPath: "lib/poems/nali.txt",
  ),
  Poets(
    id: 5,
    name: "Piramerd",
    image: "lib/images/piramerd.jpg",
    peomPath: "lib/poems/piramerd.txt",
  ),
  Poets(
    id: 6,
    name: "Salm",
    image: "lib/images/salm.jpg",
    peomPath: "lib/poems/salm.txt",
  ),
];
