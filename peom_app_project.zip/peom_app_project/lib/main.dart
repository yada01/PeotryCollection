import 'package:flutter/material.dart';
import 'package:peom_app_project/home.dart';
import 'package:peom_app_project/login.dart';
import 'package:peom_app_project/colors.dart' as colors;
import 'package:peom_app_project/poem.dart';
import 'package:peom_app_project/poem_list.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    });

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors.gradient_one,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Image.asset(
            'lib/images/splash.png',
            width: 300,
            height: 300,
          ),
        ),
      ),
    );
  }
}
