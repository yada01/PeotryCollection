import 'package:flutter/material.dart';
import 'package:peom_app_project/home.dart';
import 'package:peom_app_project/colors.dart' as colors;

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Login',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: colors.appbar_two,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors.gradient_two,
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Welcome',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: colors.login_color,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 40),
              TextField(
                style: TextStyle(color: colors.login_color), // Changed here
                decoration: InputDecoration(
                  labelText: 'Username',
                  labelStyle: TextStyle(color: colors.login_color),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: colors.login_color),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: colors.login_color),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: colors.login_color),
                  ),
                  prefixIcon:
                      Icon(Icons.account_box, color: colors.login_color),
                ),
              ),
              SizedBox(height: 20),
              TextField(
                obscureText: true,
                style: TextStyle(color: colors.login_color), // Changed here
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: colors.login_color),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: colors.login_color),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: colors.login_color),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: colors.login_color),
                  ),
                  prefixIcon: Icon(Icons.key, color: colors.login_color),
                ),
              ),
              SizedBox(height: 40),
              Container(
                padding: EdgeInsets.symmetric(
                    vertical: 10), // Change margin to padding
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => HomeScreen()),
                    );
                  },
                  child: Text(
                    'Login',
                    style: TextStyle(
                        color: Color.fromARGB(255, 25, 114, 120),
                        fontWeight: FontWeight.bold,
                        fontSize: 24),
                  ),
                  style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      backgroundColor: colors.login_color),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
